#include "Objects.h"

int Sprite::LEFT = 0;
int Sprite::RIGHT = 1;
int Sprite::HERO = 0;
int Sprite::BULLET = 1;
int Sprite::ENEMYGUY = 2;
int Sprite::GLASS = 3;
/*
Collisions::Collisions()
{
}

Collisions::~Collisions()
{
}

int* Collisions::collided(Sprite *s, Sprite *s2)
{
    int *temp;
   // s->mask->w;
    temp = new int[2];
    temp[0] = 1;
    temp[1] = 1;
    return temp;
}
*/
Entity::Entity(ENGINE *p, MapH *m)
{
   parent = p;
   mp = m;
}

Entity::~Entity()
{
   parent = 0;
   mp = 0;
}

CAMERA::CAMERA(ENGINE *p, MapH *m, Entity *sp) : Entity(p, m)
{
   x_pos = oldX = oldY = y_pos = 0;
   spotlight = NULL;// sp;
}

void CAMERA::update()
{
   
   if(key[KEY_Q])
     y_pos = ((Sprite*)spotlight)->getY();
   if(spotlight != NULL)  //used for stiff navigation
   {
    printf("%f\n", ((Sprite*)spotlight)->getY());
      oldX = ((Sprite*)spotlight)->getX()-SCREEN_W/2 + ((Sprite*)spotlight)->getWidth()/2;
      oldY = ((Sprite*)spotlight)->getY()-SCREEN_H/2 + ((Sprite*)spotlight)->getHeight()/2;
      if(((Sprite*)spotlight)->getDirection() == Sprite::RIGHT && oldX>x_pos-210)
      {
         if(oldX-x_pos>-150)
           x_pos += 12;
         x_pos += 4;
       
      }
      else if(((Sprite*)spotlight)->getDirection() == Sprite::LEFT && oldX<x_pos+210)
      {
         if(oldX-x_pos<150)
          x_pos -= 12;
         x_pos -= 4;
      }
      if(oldY<y_pos-80)  //you jumped
      {
         y_pos -= 6;
      }
      if(oldY>y_pos-80&&oldY<y_pos)
      {
         y_pos +=6;
      }
     // if(oldY<y_pos
      //y_pos = oldY;

   }
    if(key[KEY_RIGHT])
      x_pos+=16;
    if(key[KEY_DOWN])
      y_pos+=16;
    if(key[KEY_LEFT])
      x_pos-=16;
    if(key[KEY_UP])
      y_pos-=16;

    if(x_pos<0)
      x_pos = 0;
    else if(x_pos>(mapwidth*32)-SCREEN_W)
      x_pos = (mapwidth*32)-SCREEN_W;
    if(y_pos<0)
      y_pos = 0;
    else if(y_pos>(mapheight*32)-SCREEN_H)
      y_pos = mapwidth *32 - SCREEN_H;
    //else if(y_pos>
}

CAMERA::~CAMERA()
{}

Sprite::Sprite(ENGINE *p, MapH *m) : Entity(p, m)
{
  // grv = new GRAVITY();
   image = NULL;
   mask = NULL;
   x = oldX = dx = -100;
   y = oldY = dy = -100;
   rotateAngle = 0;
   pivotX = pivotY = 0;
   moveToSpeed = 0;
   direction = RIGHT;
   hasGravity = false;
   vertMovement = 0;
   gravityOffset = 0;
}

Sprite::Sprite(ENGINE *p, MapH *m, float xp, float yp) : Entity(p, m)
{
   image = NULL;
   mask = NULL;
   x = oldX = dx = xp;
   y = oldY = dy = yp;
   rotateAngle = 0;
   pivotX = pivotY = 0;
   moveToSpeed = 0;
   direction = RIGHT;
   hasGravity = false;
   vertMovement = 0;
   gravityOffset = 0;
}

Sprite::Sprite(ENGINE *p, MapH *m, BITMAP *b, bool dataBMP) : Entity(p, m)
{
   image = b;
   mask = create_allegro_pmask(b);
   dataImage = dataBMP;
   x = oldX = dx = -100;
   y = oldY = dy = -100;
   rotateAngle = 0;
   pivotX = pivotY = 0;
   moveToSpeed = 0;
   direction = RIGHT;
   hasGravity = false;
   vertMovement = 0;
   gravityOffset = 0;
}

Sprite::Sprite(ENGINE *p, MapH *m, BITMAP *b, float xp, float yp, bool dataBMP) : Entity(p, m)
{
    image = b;
    mask = create_allegro_pmask(b);
    dataImage = dataBMP;
    x = oldX = dx = xp;
    y = oldY = dy = yp;
    rotateAngle = 0;
    pivotX = pivotY = 0;
    moveToSpeed = 0;
    direction = RIGHT;
    hasGravity = false;
    vertMovement = 0;
    screenX = x - mp->camera->getX();//getCameraX();
    screenY = y - mp->camera->getY();//getCameraY();
    gravityOffset = 0;
}

void Sprite::draw()
{
    // if(rotateAngle == 0)
       draw_sprite(parent->gHandler->getBuffer(), image, (int)screenX, (int)screenY);
}

void Sprite::drawPivot(int angle)
{
     pivot_sprite(parent->gHandler->getBuffer(), image, (int)screenX, (int)screenY, pivotX, pivotY, itofix(angle));
}

void Sprite::drawFlip()
{
     draw_sprite_h_flip(parent->gHandler->getBuffer(), image, (int)screenX, (int)screenY);
}

void Sprite::drawTrans(int alpha)
{
   set_trans_blender(0, 0, 0, alpha);
   draw_trans_sprite(parent->gHandler->getBuffer(), image, (int)screenX, (int)screenY);
}

void Sprite::drawAlpha()
{
   set_alpha_blender();
   draw_trans_sprite(parent->gHandler->getBuffer(), image, (int)screenX, (int)screenY);
}

void Sprite::update()
{
     if(dx != x)
     {
       if(dx>x)
         x+=moveToSpeed;
       else
         x-=moveToSpeed;
         
       if(abs((int)(dx-x))<moveToSpeed)
         x = dx;
     }
     if(dy != y)
     {
       if(dy>y)
         y+=moveToSpeed;
       else
         y-=moveToSpeed;
         
       if(abs((int)(dy-y))<moveToSpeed)
         y = dy;
     }
     if(hasGravity)
       onGround = calculateGravity();
     //calculate map collision 


    screenX = x - mp->camera->getX();//getCameraX();
    screenY = y - mp->camera->getY();

    if(y>mapheight*32) isActive = false;
    
}

int Sprite::checkCollisions()
{
    for(int i = 0; i<mp->Entities.size(); i++)
    {
            if(this != mp->Entities[i])
            {
                Sprite *comp = (Sprite*)mp->Entities[i];
                if(mask==NULL||mask==0)
                {
                   allegro_message("A mask is NULL someplace");
                   return 0;
                }
                //printf("%p\n", mask);
                if (check_pmask_collision(mask, comp->getMask(), (int)x,(int)y, (int)comp->getX(),(int)comp->getY())) {
                    collisionHappened(comp);
                }
            }
    }
}

void Sprite::collisionHappened(Sprite *s)
{
    // check against the ma
      
}

void Sprite::moveTo(float xs, float ys, float speed)
{
     dx = xs;
     dy = ys;
     moveToSpeed = speed;
}

void Sprite::tryMoveX(int xval)
{
    // allegro_message("popped with xval of %d, xcoord of %f", xval, x);
     if(xval == 0)
      return;
     int temp = xval;
     while(temp>0)  //move towards right
     {
   //     if(check_pmask_collision(mask, 
        x+=1;
       // dx
        temp--;
     }
     while(temp<0)
     {
        x-=1;
        temp++;
     }
     
   //  allegro_message("end with xval of %d, xcoord of %f", xval, x);
}

bool Sprite::calculateGravity()
{
     vertMovement -= 2;
    // y-=vertMovement;
     
    //if(*v>64)
    //  *v = 64;
   // else if(*v<-64)
    //  *v = -64;
    //*y-=1;
    //printf("%f\n", *y);
   // return 0;
    if(vertMovement==0)
      return false;
    if(vertMovement>0)
    {
       int temp = (int)vertMovement;
       while(temp>0)
       {
         /*if(mp->checkMask(mask, (int)x, (int)y-1))
         {
           vertMovement = 0;
           return false;
         }*/
         y-=1;
         temp--;
      }
      return false;
    }
    
    if(vertMovement<0)
    {
       int temp = (int)vertMovement;
       while(temp<0)
       {
          if(mp->checkCollision((int)x, (int)y+mask->h)||mp->checkCollision((int)x+16, (int)y+mask->h)||mp->checkCollision((int)x+31, (int)y+mask->h))
          {
           vertMovement = 0;
           return true;
          }
         y+=1;
         temp++;
      }
      return false;
    }
}


Sprite::~Sprite()
{
    //printf("KILLING SPRITE");
     if(!dataImage && image != NULL)
       destroy_bitmap(image);
     if(mask != NULL)
       destroy_pmask(mask);
    // image = 0;
    // mask = 0;
     
}

AnimatedSprite::AnimatedSprite(ENGINE *p, MapH *m, bool dataBMP) : Sprite(p, m, -100, -100)
{
   dataImage = dataBMP;
   currentFrame = 0;
   startFrame = 0;
   animSpeed = 5;
   animate = false;
}

AnimatedSprite::AnimatedSprite(ENGINE *p, MapH *m, float xp, float yp, bool dataBMP) : Sprite(p, m, xp, yp)
{
   dataImage = dataBMP;
   currentFrame = 0;
   startFrame = 0;
   animSpeed = 5;
   animate = false;
}

AnimatedSprite::~AnimatedSprite()
{
  // allegro_message("~AnimatedSprite()");
  
   while( images.size() > 0 )
   {
    if(!dataImage)
      destroy_bitmap(images.back());
    images.pop_back();
   }
   if(mask!=NULL)
     destroy_pmask(mask);
  // allegro_message("End AnimatedSprite()");
}

void AnimatedSprite::update()
{
   if(animate)
   {
     startFrame++;
     if(startFrame>animSpeed)
     {
       currentFrame++;
       startFrame = 0;
       if(currentFrame>=images.size())
         currentFrame = 0;
     }  
   }
   Sprite::update();
}

void AnimatedSprite::addImage(BITMAP *img)
{
     images.push_back(img);
     if(images.size()==1)
       mask = create_allegro_pmask(img);
}

void AnimatedSprite::draw()
{
   if(images.size()!=0)
     draw_sprite(parent->gHandler->getBuffer(), images[currentFrame], (int)screenX, (int)screenY);
}

void AnimatedSprite::drawFlip()
{
   if(images.size()!=0)
     draw_sprite_h_flip(parent->gHandler->getBuffer(), images[currentFrame], (int)screenX,(int)screenY);
}

void AnimatedSprite::drawPivot()
{
     pivot_sprite(parent->gHandler->getBuffer(), images[currentFrame], (int)screenX, (int)screenY, pivotX, pivotY, itofix(rotateAngle));
}

Hero::Hero(ENGINE *p, MapH *m, float xp, float yp) : Sprite(p, m, xp, yp)
{        
   init();
}

Hero::~Hero()
{
   delete feet;
   delete []feetJump;
   delete []gun;
   delete []head;
   delete []torso;
}

void Hero::init()
{
     direction = RIGHT;
     head[RIGHT] = new Sprite(parent, mp, parent->loadH->grabBitmap(HEADRIGHT), true);//load_bitmap("headleft.bmp", NULL);
     head[LEFT] = head[RIGHT];
     feet = new AnimatedSprite(parent, mp, true);
     for(int i = 0; i<7; i++)
     {
       feet->addImage(parent->loadH->grabBitmap(FEET000+i));//load_bitmap("feet2.bmp", NULL);
      // maskFeet[i] = create_allegro_pmask((BITMAP*)loadH.get(FEET000+i));
     }
     feetJump[LEFT] = new Sprite(parent, mp, parent->loadH->grabBitmap(FEETJUMP), true);
     feetJump[RIGHT] = feetJump[LEFT];
     torso[LEFT] = new Sprite(parent, mp, parent->loadH->grabBitmap(TORSOLEFT), true);//load_bitmap("torsoleft.bmp", NULL);
     torso[RIGHT] = new Sprite(parent, mp, parent->loadH->grabBitmap(TORSORIGHT), true);//load_bitmap("torsoright.bmp", NULL);
     gun[LEFT] = new Sprite(parent, mp, parent->loadH->grabBitmap(ARMGUNLEFT), true);//load_bitmap("gunleft.bmp", NULL);
     gun[LEFT]->pivotPoints(83, 7);
     gun[RIGHT] = new Sprite(parent, mp, parent->loadH->grabBitmap(ARMGUNRIGHT), true);//load_bitmap("gunright.bmp", NULL);
     gun[RIGHT]->pivotPoints(10, 10);
     crosshair = new Sprite(parent, mp, parent->loadH->grabBitmap(Crosshair), true);
     bobage = 1;
     canJump = false;
    // jumpAcceleration = 0;
     isWalking = false;
     recoilTime = 0;
     hasGravity = true;
     weaponOut = 0;
     shotAngle = 10;

     BITMAP *fake = create_bitmap(64, 216);
     clear_to_color(fake, makecol(0, 0, 0));
     mask = create_allegro_pmask(fake);
     delete fake;
   
     spriteType = HERO;
   //  hud = new HUD(parent, this);
     //col = new Collisions();
}

void Hero::draw()
{
     if(direction==RIGHT)
     {
                         
                         
       gun[direction]->drawPivot((int)shotAngle);
             
       switch(onGround)
       {
          case true:
            feet->draw();
            break;
          case false:
            feetJump[direction]->draw();
            break;
       }
       torso[direction]->draw();
       head[direction]->draw();
     }
     else if(direction == LEFT)
     {
       switch(onGround)
       {
          case true:
            feet->drawFlip();
            break;
          case false:
            feetJump[direction]->drawFlip();
            break;
       }
       torso[direction]->setX(x);torso[direction]->setY(y+40+bobage);
       torso[direction]->draw();
       head[direction]->setX(x+3);head[direction]->setY(y+5+bobage);
       head[direction]->drawFlip();
       gun[direction]->setX(x+50);gun[direction]->setY(y+80);
       
             gun[direction]->drawPivot((int)shotAngle);
     }

     //crosshair->setScreenY(50);
     crosshair->drawAlpha();
    // draw_allegro_pmask(mask, parent->gHandler->getBuffer(), (int)screenX, (int)screenY, 15);
    // hud->draw();
}

void Hero::collisionHappened(Sprite *other)
{
     if(other->getType() == ENEMYGUY)
     {
         if((getX()+getWidth()/2)>(other->getX()+other->getWidth()))
         {
            x += 4;
         }
     }
}
void Hero::update()
{
     isWalking = false;
     isFiring = false;
     oldY = y;
     if(parent->inputH->isPressed("right"))
     {
       oldX = x;
       if(screenX<580&&x<mapwidth*32-4)
         x+=4;
       bobage = 0;
       if(feet->getFrame()==1)
        bobage = 1;
       else if(feet->getFrame()==4)
        bobage = 1;
       isWalking = true;
       
     }
     else if(parent->inputH->isPressed("left"))
     {
      // tryMoveX(-4);
       oldX = x;
       if(screenX>0)
       x-=4;
      // direction = LEFT;
       bobage = 0;
       if(feet->getFrame()==1)
        bobage = 1;
       else if(feet->getFrame()==4)
        bobage = 1;
       isWalking = true;
     }
     if(crosshair->getX()+16>x+40)
       direction = RIGHT;
     else
       direction = LEFT;
     if(direction == RIGHT)
     {
      shotAngle = atan((fix)(((mouse_y+16) - (screenY+80))/((mouse_x+16) - (screenX+40))));//update here
      if(shotAngle>45)
       shotAngle = 45;
      else if(shotAngle<-45)
       shotAngle = -45;
     }
     else if(direction == LEFT)
     {
      shotAngle = atan((fix)(((screenY+80) - (mouse_y+16))/((screenX+40)-(mouse_x+16))));
      if(shotAngle>45)
       shotAngle = 45;
      else if(shotAngle<-45)
       shotAngle = -45;
     }
     
     if(parent->inputH->isTapped("weapon"))
     {
       weaponOut++;
       if(weaponOut>1)
         weaponOut = 0;
         
       Sprite *j = new HSR(parent, mp, 100, 10, 1);
       mp->addObj(j);
     }
     
     
     if(parent->inputH->isTapped("jump")&&onGround)
     {
        onGround = false;
        vertMovement = 25;
     }
     feet->setLocation(x, y+140);
     feet->setAnimate(isWalking);
     feet->update();
     
     crosshair->setX(mp->camera->getX() + mouse_x);
     crosshair->setY(mp->camera->getY() + mouse_y);
     crosshair->update();
     
     switch(direction)
     {
        case 1:
          gun[RIGHT]->setLocation(x+40, y+80);
          feetJump[RIGHT]->setLocation(x, y+140);
          torso[RIGHT]->setLocation(x, y+40+bobage);
          head[RIGHT]->setLocation(x+5, y+5+bobage);
        break;
        case 0:
          feetJump[LEFT]->setLocation(x, y+140);
          torso[LEFT]->setLocation(x, y+40+bobage);
          head[LEFT]->setLocation(x+3, y+5+bobage);
          gun[LEFT]->setLocation(x+50, y+80);
     }
     for(int d = 0; d < 2; d++)
     {
       feetJump[d]->update();
       head[d]->update();
       torso[d]->update();
       gun[d]->update();
     }
     
     if(parent->inputH->isTapped("fire"))
     {
        Bullet *sp = NULL;
        sp = new Bullet(parent, mp, gun[direction], shotAngle, direction);
        mp->addObj(sp);
        recoilTime = 10;
        isFiring = true;
        /*if(direction==0)
        {
          Particle *p = new Particle((int)x-40, (int)y+70, .5, -1, BLUE, 40, parent, mp, true);
          Particle *p1 = new Particle((int)x-40, (int)y+76, .5, 1, RED, 40,  parent, mp, true);
          Particle *p2 = new Particle((int)x-40, (int)y+70, 1, .5, YELLOW, 40, parent, mp, true);
          Particle *p3 = new Particle((int)x-40, (int)y+76, 1, -.5, GREEN, 40, parent, mp, true);
          mp->addPtcl(p);
          mp->addPtcl(p1);
          mp->addPtcl(p2);
          mp->addPtcl(p3);
        }
        else if(direction==1)
        {
          Particle *p = new Particle((int)x+125, (int)y+70, -.5, -1, BLUE, 40, parent, mp, true);
          Particle *p1 = new Particle((int)x+125, (int)y+76, -.5, 1, RED, 40, parent, mp, true);
          Particle *p2 = new Particle((int)x+125, (int)y+70, -1, .5, YELLOW, 40, parent, mp, true);
          Particle *p3 = new Particle((int)x+125, (int)y+76, -1, -.5, GREEN, 40, parent, mp, true);
          
         // Particle *shot = new Particle((int)x+125, (int)y+70, 1, 0, RED, 10, parent, mp, false);
          mp->addPtcl(p);
          mp->addPtcl(p1);
          mp->addPtcl(p2);
          mp->addPtcl(p3);
         // mp->addPtcl(shot);
        }*/
     }
     recoilTime--;
     isFiring = true;
     if(recoilTime <= 0)
       isFiring = false;
     Sprite::update();
}

Bullet::Bullet(ENGINE *p, MapH *m, Sprite *gun, float angle, int dir) : Sprite(p, m, -100, gun->getY()+72)
{    
  direction = dir;
  myAngle = angle;
  mask = create_allegro_pmask(parent->loadH->grabBitmap(BULLETRIGHT));
  timer = 0;
  spriteType = BULLET;
  isActive = true;
  if(direction == LEFT)
  {
    bul = new Sprite(parent, mp, parent->loadH->grabBitmap(BULLETLEFT), true);//(BITMAP*)parent->loadH->get(BULLETLEFT);
    bul->setX((gun->getX()-12)-(cos((fix)(myAngle))*90));
    bul->setY((gun->getY()-7)-(sin((fix)(myAngle))*90));
  }
  else if(direction == RIGHT)
  {
    bul = new Sprite(parent, mp, parent->loadH->grabBitmap(BULLETRIGHT), true);
    bul->setX((gun->getX())+(cos((fix)(myAngle))*90));
    bul->setY((gun->getY()-7)+(sin((fix)(myAngle))*90));
  }
  
}

Bullet::~Bullet()
{
  delete(bul);
}

void Bullet::update()
{
  if(direction == LEFT)
  {
    bul->setX(bul->getX() - (cos((fix)(myAngle)) * 14));
    bul->setY(bul->getY() - (sin((fix)(myAngle)) * 14));
  }
  else if(direction == RIGHT)
  {
    bul->setX(bul->getX() + (cos((fix)(myAngle)) * 14));
    bul->setY(bul->getY() + (sin((fix)(myAngle)) * 14));
  }
  x = bul->getX();  //why set these too?  for collisions
  y = bul->getY();
  Sprite::update();
  bul->update();
  timer++;
  if(timer>100)
      mp->remObj(this);
    //  isActive = false;
}

void Bullet::draw()
{
    bul->drawPivot((int)myAngle);
}

Glass::Glass(ENGINE *p, MapH *m, Sprite *s, float xV, float yV) : Sprite(p, m, -100, -100)
{
     thing = s;
     thing->pivotPoints(s->getMask()->w/2, s->getMask()->h/2);
     BITMAP *temp = create_bitmap(s->getMask()->w, s->getMask()->h);
     clear_to_color(temp, makecol(0, 0, 0));
     mask = create_allegro_pmask(temp);
     xVel = xV;
     yVel = yV;
     angle = 0;
     animAngle = 0;
     thing->hasGravity = true;
     isActive = true;
     timer = 0;
     spriteType = GLASS;
}

Glass::~Glass()
{
     destroy_pmask(mask);
     mask = 0;
     delete(thing);
}

void Glass::update()
{
     if(yVel>20)
       yVel = 20;
     else if (yVel<-20)
       yVel = -20;
     thing->setX(thing->getX() + xVel);
     thing->setY(thing->getY() + yVel);
     //y += yVel;
     if(thing->getX()<0&&xVel<0)
     {
       xVel = -xVel;
       thing->setX(0);
     }
     if(thing->getY()<0&&yVel<0)
       yVel = -yVel;
     
     if(animAngle>0)
     {
       angle+=4;
       animAngle--;
     }
     else if(animAngle<0)
     {
       angle-=4;
       animAngle++;
     }
     if(xVel>0)
      xVel -= .5;
     else if(xVel<0)
      xVel += .5;
      
     if(yVel>0)
      yVel -= .5;
     else if(yVel<0)
      yVel += .5;
     x = thing->getX();
     y = thing->getY()-10;
     Sprite::update();
     thing->update();
 //    timer++;
  //   if(timer>100)  //kill this
  //     isActive = false;

}

void Glass::draw()
{
     thing->drawPivot((int)angle);
}

void Glass::collisionHappened(Sprite *other)
{
     if(other->getType() == BULLET)
     {
         timer = 0;
         mp->remObj(other);
         yVel-=10;
         if(other->getDirection()==LEFT)
           xVel-=5;
         else
           xVel+=5;
         
         if((mask->h/2+y)<other->getY()+15 && other->getDirection()==LEFT)
         {
            animAngle = 30;
         }
         else if((mask->h/2+y)<other->getY()+15 && other->getDirection()==RIGHT)
         {
            animAngle = -30;
         }
     }
     else if(other->getType() == GLASS)
     {
         if(xVel==((Glass*)other)->xVel)
         {
            if(mask->w+x>other->getMask()->w+other->getX())
            {
              xVel+=1;
            }
            else
             xVel += -1;
         }
     }
}

HSR::HSR(ENGINE *p, MapH *m, float xp, float yp, int dir) : Sprite(p, m, xp, yp)
{
   direction = dir;
   headOn = true;
   torsoOn = true;
   eyes = new Sprite(parent, mp, parent->loadH->grabBitmap(HSREYES), true);
   head = new Sprite(parent, mp, parent->loadH->grabBitmap(HSRHEAD), true);//load_bitmap("head.bmp", NULL));//, -100, -100, );
   mouth = new Sprite(parent, mp, parent->loadH->grabBitmap(HSRMOUTH), true);//load_bitmap("mouth.bmp", NULL));
   torso = new Sprite(parent, mp, parent->loadH->grabBitmap(HSRTORSO), true);//load_bitmap("torso.bmp", NULL));
  // legs[0] = new Sprite(parent, mp, true);
   
   
   BITMAP *fake = create_bitmap(64, 216);
   clear_to_color(fake, makecol(0, 0, 0));
   mask = create_allegro_pmask(fake);
   delete fake;
   hasGravity = true;
   //gravityOffset = 80;
   //legs[0]->setAnimate(true);
   spriteType = ENEMYGUY;
   movin = true;
   isActive = true;
   setOnce = false;
   timer = -1;
   
   temp[0] = create_bitmap(64, 64);
   temp[1] = create_bitmap(64, 64);
   temp[2] = create_bitmap(100, 100);
   clear_to_color(temp[0], makecol(255, 0, 255));
   clear_to_color(temp[1], makecol(255, 0, 255));
   clear_to_color(temp[2], makecol(255, 0, 255));
   draw_sprite_h_flip(temp[0], parent->loadH->grabBitmap(HSRHEAD), 0, 0);
   draw_sprite_h_flip(temp[0], parent->loadH->grabBitmap(HSREYES), 28, 16);
   draw_sprite_h_flip(temp[0], parent->loadH->grabBitmap(HSRMOUTH), 28, 27);
   draw_sprite_h_flip(temp[1], temp[0], 0, 0);
   draw_sprite_h_flip(temp[2], parent->loadH->grabBitmap(HSRTORSO), 0, 0);
   //head->getX(), head->getY());    
}

HSR::~HSR()
{
      delete eyes;
   //   delete []legs;
      delete torso;
      delete mouth;
      delete head;
    
}

void HSR::update()
{
  // if(movin)
  // {
  //   oldX = x;
  //   oldY = y;
     //x+=3;
  // }
   if(direction==LEFT)
   {
        x--;
        if(x<50)
         direction = RIGHT;
   }
   else if(direction==RIGHT)
   {
        x++;
        if(x>150)
         direction = LEFT;
   }
   
   if(direction==LEFT)
   {
     if(torsoOn)
       torso->setLocation(x, y+55);
   //  legs[0]->setLocation(x+3, y+115);
  //   legs[1]->setLocation(x-9, y+112);
     if(headOn)
     {
       eyes->setLocation(x+28, y+16);
       head->setLocation(x+15, y);
       mouth->setLocation(x+5, y+27);
     }
   }
   else if(direction==RIGHT)
   {
     if(torsoOn)
     torso->setLocation(x, y+55);
  //   legs[0]->setLocation(x+28, y+112);
  //   legs[1]->setLocation(x+19, y+115);
     if(headOn)
     {
       eyes->setLocation(x+24, y+16);
       head->setLocation(x-4, y);
       mouth->setLocation(x+24, y+27);
     }
   }
   if(headOn)
   {
     mouth->update();
     head->update();
     eyes->update();
   }
   if(torsoOn)
   torso->update();
  
  // legs[0]->update();
  // legs[1]->update();
   Sprite::update();
  
   if(timer>0)
     timer--;
   if(timer==0)
    isActive = false;
     
  //   mp->remObj(this);
   
    // mp->remObj(this);
   
   //movin = true;
}

void HSR::draw()
{
   if(direction==LEFT)
   {
  //   legs[1]->draw();
 //    legs[0]->draw();
   //draw_allegro_pmask(legs[1]->getMask(), parent->gHandler->getBuffer(), (int)screenX, (int)screenY, 15);
     if(torsoOn)
     torso->draw();
     if(headOn)
     {
       head->draw();
       mouth->draw();
       eyes->draw();
     }
   }
   else if(direction==RIGHT)
   {
   //  legs[0]->drawFlip();
  //   legs[1]->drawFlip();
  // draw_allegro_pmask(head->getMask(), parent->gHandler->getBuffer(), (int)screenX, (int)screenY, 15);
     if(torsoOn)
     torso->drawFlip();
     if(headOn)
     {
       head->drawFlip();
       mouth->drawFlip();
       eyes->drawFlip();
     }
   }
}

void HSR::collisionHappened(Sprite *other)
{    
     if(other->getType() == BULLET)
     {      
         if(torsoOn)
         {
            if ((check_pmask_collision(other->getMask(), torso->getMask(), (int)other->getX(),(int)other->getY(), (int)torso->getX(),(int)torso->getY()))) 
            {                                        
              mp->remObj(other);  
              torsoOn = false;   
              timer = 100;
              if(headOn)
              {//a
             
                headOn = false;
                if(other->getDirection()==RIGHT)
                {
                 tempSpr[0] = new Sprite(parent, mp, temp[0], head->getX(), head->getY(), false);
                 g[0] = new Glass(parent, mp, tempSpr[0], 20, -15);
                 mp->addObj(g[0]);
                }
                else if(other->getDirection() == LEFT)
                {
                   tempSpr[1] = new Sprite(parent, mp, temp[1], head->getX(), head->getY(), false);
                   g[1] = new Glass(parent, mp, tempSpr[1], -20, -15);
                   mp->addObj(g[1]);
                }
               }//a
               if(other->getDirection()==LEFT)
               {
                 tempSpr[2] = new Sprite(parent, mp, parent->loadH->grabBitmap(HSRTORSO), head->getX(), head->getY(), true);
                 g[2] = new Glass(parent, mp, tempSpr[2], -20, -15);
                 mp->addObj(g[2]);
               }
               else if(other->getDirection()==RIGHT)
               {
                 tempSpr[3] = new Sprite(parent, mp, temp[2], head->getX(), head->getY(), false);
                 g[3] = new Glass(parent, mp, tempSpr[3], 20, -15);
                 mp->addObj(g[3]);
               }
           }
         }  
         if(headOn)
         {
           if ((check_pmask_collision(other->getMask(), head->getMask(), (int)other->getX(),(int)other->getY(), (int)head->getX(),(int)head->getY()))) 
           {
              mp->remObj(other);  
              headOn = false;
              timer = 100;
              if(other->getDirection()==RIGHT)
              {
                 tempSpr[0] = new Sprite(parent, mp, temp[0], head->getX(), head->getY(), false);
                 g[0] = new Glass(parent, mp, tempSpr[0], 20, -15);
                 mp->addObj(g[0]);
              }
              else if(other->getDirection() == LEFT)
              {
                 tempSpr[1] = new Sprite(parent, mp, temp[1], head->getX(), head->getY(), false);
                 g[1] = new Glass(parent, mp, tempSpr[1], -20, -15);
                 mp->addObj(g[1]);
              }
           }
         }
     } //end bullet statement
}


