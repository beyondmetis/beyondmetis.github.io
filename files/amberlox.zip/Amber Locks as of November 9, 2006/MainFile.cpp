#include <allegro.h>
#include "Engine.h"

/*
   main() function theory:
         start by declaring the engine
         initialize that engine
         run that engine (through the menu, then into the game)
         cleanup the engine
         delete the engine
         quit the program
         :) simple
   */
int main()
{
    ENGINE eng;
    
    if(eng.init()<0)
    {
       allegro_message("ERROR: eng.init()");
       return 0;
    }
    
    eng.run();
    eng.cleanup();
    delete(&eng);
    //exit(1);
    return 0;
}
END_OF_MAIN()
