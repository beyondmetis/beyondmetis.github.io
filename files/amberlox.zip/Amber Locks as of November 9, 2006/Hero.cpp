#include "Object.h"

Hero::Hero()
{        
}

Hero::~Hero()
{
  // allegro_message("~hero()");
  // delete []torso;
  // delete []gun;
  // delete []head;
  // delete feet;
   //*torso = 0;
   //*gun = 0;
  // *head = 0;
   //feet = 0;
  //  allegro_message("Killed Hero");
}

void Hero::init()
{
     LEFT = 0;
     RIGHT = 1;
     DIRECTION = RIGHT;
     head[RIGHT] = new Sprite((BITMAP*)loadH.get(HEADRIGHT), -100, -100);//load_bitmap("headleft.bmp", NULL);
     head[LEFT] = head[RIGHT];
     feet = new AnimatedSprite(-100, -100);
     for(int i = 0; i<7; i++)
     {
       feet->addImage((BITMAP*)loadH.get(FEET000+i));//load_bitmap("feet2.bmp", NULL);
       maskFeet[i] = create_allegro_pmask((BITMAP*)loadH.get(FEET000+i));
     }
     torso[LEFT] = new Sprite((BITMAP*)loadH.get(TORSOLEFT), -100, -100);//load_bitmap("torsoleft.bmp", NULL);
     torso[RIGHT] = new Sprite((BITMAP*)loadH.get(TORSORIGHT), -100, -100);//load_bitmap("torsoright.bmp", NULL);
     gun[LEFT] = new Sprite((BITMAP*)loadH.get(ARMGUNLEFT), -100, -100);//load_bitmap("gunleft.bmp", NULL);
     gun[LEFT]->pivotPoints(83, 7);
     gun[RIGHT] = new Sprite((BITMAP*)loadH.get(ARMGUNRIGHT), -100, -100);//load_bitmap("gunright.bmp", NULL);
     gun[RIGHT]->pivotPoints(10, 10);
     bobage = 1;
     swing = 10;
     canJump = false;
     gravity = 2;
     jumpAcceleration = 0;
     x = 300;
     y = 100;
     decAngle=0.0;
     isWalking = false;
     screenX = -1000;
}

void Hero::draw()
{
     if(DIRECTION==RIGHT)
     {
       gun[DIRECTION]->setX(screenX+40);gun[DIRECTION]->setY(screenY+80);
       gun[DIRECTION]->drawPivot(swing);
       feet->setX(screenX);feet->setY(screenY+140);
       feet->draw();
       torso[DIRECTION]->setX(screenX);torso[DIRECTION]->setY(screenY+40+bobage);
       torso[DIRECTION]->draw();
       head[DIRECTION]->setX(screenX+5);head[DIRECTION]->setY(screenY+3+bobage);
       head[DIRECTION]->draw();
     }
     else if(DIRECTION == LEFT)
     {
       feet->setX(screenX);feet->setY(screenY+140);
       feet->drawFlip();
       torso[DIRECTION]->setX(screenX);torso[DIRECTION]->setY(screenY+40+bobage);
       torso[DIRECTION]->draw();
       head[DIRECTION]->setX(screenX+3);head[DIRECTION]->setY(screenY+3+bobage);
       head[DIRECTION]->drawFlip();
       gun[DIRECTION]->setX(screenX+50);gun[DIRECTION]->setY(screenY+80);
       gun[DIRECTION]->drawPivot(swing);
      /// draw_sprite_h_flip(graphH.getBuffer(), feet[feetFrame], screenX, Y+150);
      // graphH.drawImage(torso[LEFT], screenX + 0, Y + 50 + bobage);
      // pivot_sprite(graphH.getBuffer(), gun[LEFT], screenX+50, Y+90, 83, 7, itofix(swing));
     //  draw_sprite_h_flip(graphH.getBuffer(), head[RIGHT], screenX, Y + bobage);
       //graphH.drawImage(head[LEFT], X + 0, Y + 0 + bobage);
     }
     // if(BOTTOMCOLLISION)
    // textprintf(graphH.getBuffer(), font, 200, 10, 2225, "check: %d", check); 
}

void Hero::update()
{
     isWalking = false;
     //blit(torso, subBuffer, 0, 0, 0, 60, torso->w, torso->h);
     //blit(head, subBuffer, 0, 0, 0, 0, head->w, head->h);
     swing=0;
     if(key[KEY_RIGHT])
     {
       x+=4;
       DIRECTION = RIGHT;
       if(bobage>0)
         decAngle+=0.05;
       else if(bobage<0)
         decAngle-=0.05;
       if(decAngle > 0.2)
         bobage=-1;
       else if(decAngle < -0.2)
         bobage=1;
       swing = (int)asin(decAngle);
       isWalking = true;
       
     }
     else if(key[KEY_LEFT])
     {
       x-=4;
       DIRECTION = LEFT;
       if(bobage>0)
         decAngle+=0.05;
       else if(bobage<0)
         decAngle-=0.05;
       if(decAngle > 0.2)
         bobage=-1;
       else if(decAngle < -0.2)
         bobage=1;
       swing = (int)asin(decAngle);
       isWalking = true;
     }
     
     
     if(key[KEY_SPACE]&&canJump)
     {
        jumpAcceleration=25;
        canJump = false;
     }
     if(isWalking)
       feet->update();
     Sprite::update();
     //y+=;
     //y-=jumpAcceleration;
     if(!canJump)
       jumpAcceleration-=2;
     int temp = jumpAcceleration;
     int mx, mxp, my;
     
     while(temp>0||temp<0)
     {
       mx = (int)(feet->getX() + feet->getWidth()-1);
       mxp = (int)(feet->getX() + 1);
       my = (int)(feet->getY() + feet->getHeight() + 1);
       if(temp<0)
       {
         if(mx>0&&my>0&&mxp>0)
           if(map.getFlag(mx/32, my/32)||map.getFlag(mxp/32, my/32))
           {
             jumpAcceleration = 0;
             canJump = true;
             break;
         //y--;
           }
       }
       if(temp>0)
       {
         y--;
         temp--;
       }
       else if(temp<0)
       {
         y++;
         temp++;
       }
       screenY = y - map.getCameraY();
       feet->setY(screenY+140);
     }
    // if(temp<0)
    //   y-=jumpAcceleration;
     
     if(key[KEY_SPACE]&&canJump)
     {
        jumpAcceleration = 20;
        canJump = false;
     }
     
     if(inputH.isTapped(KEY_Z))
     {
       if(DIRECTION==LEFT)
       {
         soundH.playSound(1);
         Sprite *sg = NULL;
         sg = new Bullet((int)(x-40), (int)(y+72), DIRECTION, 0);//swing);
         if(sg == NULL)
           allegro_message("Problem");
         map.addObject(sg);
       }
       else
       {  
         soundH.playSound(1);
         Sprite *sg = new Bullet((int)x+125, (int)y+72, DIRECTION, swing);
         map.addObject(sg);
       }
     }
}

Bullet::Bullet(int screenx, int screeny, int direction, int ang)
{
   x = screenx;
   y = screeny-map.getCameraY();
   DIRECTION = direction;
   isActive = true;
   angle = ang;
   time = 0;
}

Bullet::~Bullet()
{
   x = 0;
   time = 0;
   y = 0;
   angle = 0;
   //~Sprite();
   //delete this;
}

void Bullet::update()
{
   
   if(DIRECTION==0)//left
     x-=5;
   else
     x+=5;
   y += (float)(tan(0));//(float)sin(angle)*10;
   if(abs((int)(x-hero.getX()))>1000||time>100)
     isActive = false;
   Sprite::update();
}

void Bullet::draw()
{
     //screenX = x;
     //screenY = y;
    // if(screenX>1)
      rectfill(graphH.getBuffer(), (int)screenX, (int)screenY, (int)(screenX+3), (int)(screenY+2), BLACK);
    // else
    //  isActive = false;
}
