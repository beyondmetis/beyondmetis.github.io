#ifndef herohandler
#define herohandler
#include <allegro.h>
#include "GRAPHICSHANDLER.h"
#include "LOADHANDLER.h"
#include "map.h"





#endif
