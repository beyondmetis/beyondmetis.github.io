#ifndef objectsheader
#define objectsheader

#include "Engine.h"

class ENGINE;
class MapH;
class Sprite;
class Hero;

class Entity
{
    protected:
    ENGINE *parent;
    MapH *mp;
    bool isActive;
    public:
    Entity(ENGINE *p, MapH *m);
    virtual ~Entity();// { parent = 0; mp = 0; }
    virtual void update() = 0;
    virtual void draw() = 0;
    virtual float getX() = 0;
    virtual float getY() = 0;
    //virtual int getWidth() = 0;
   // virtual int getHeight() = 0;
    bool checkActive() { return isActive; }
    virtual int checkCollisions() = 0;
};

class CAMERA : public Entity {
    public:
    float x_pos, y_pos;
    float oldX, oldY;
    Entity *spotlight;
    CAMERA(ENGINE *p, MapH *m, Entity *sp);
    ~CAMERA();
    void update();
    void draw() {}
    float getX() {return x_pos;}
    float getY() {return y_pos;}
    void setFocus(Entity *s) { spotlight = s; }
    int checkCollisions() {}
};


class Sprite : public Entity
{
   protected:
     float x, y;
     float oldX, oldY;
     float screenX, screenY;
     PMASK *mask;
     int rotateAngle;
     int pivotX, pivotY;
     int direction;
     int gravityOffset;
     bool onGround;
     float horizMovement, vertMovement;
     void tryMoveX(int xval);
     int spriteType;
      bool dataImage;
   private:
     BITMAP *image;
     float dx, dy;  //moveto positions 
     float moveToSpeed;
     bool calculateGravity();
   public:
     bool hasGravity;
     static int LEFT, RIGHT;
     static int HERO, BULLET, ENEMYGUY, GLASS;
     ~Sprite();
     Sprite(ENGINE *p, MapH *m);
     Sprite(ENGINE *p, MapH *m, BITMAP *b, bool dataBMP);
     Sprite(ENGINE *p, MapH *m, float xp, float yp);
     Sprite(ENGINE *p, MapH *m, BITMAP *b, float xp, float yp, bool dataBMP);
     void setImage(BITMAP *img);
     PMASK* getMask(){ return mask; }
     virtual int getWidth() {return mask->w;}
     virtual int getHeight() {return mask->h;}
     void moveTo(float xs, float ys, float speed);
     void setLocation(float xr, float yr) { x = dx = oldX = xr; y = dy = oldY = yr; }
     float getX(){return x;}
     float getY(){return y;}
     float getOldX(){return oldX;}
     float getOldY(){return oldY;}
     int getDirection() {return direction;}
     int getType() {return spriteType;}
     void draw();
     virtual void drawFlip();
     virtual void drawPivot(int angle);
     virtual void drawTrans(int trans);
     virtual void drawAlpha();
   //  virtual void setAlphaOscillation(int lowBound, int highBound, int spd);
     void update();
     void pivotPoints(int nx, int ny) {pivotX = nx;pivotY = ny;}
     void revertX(){x = oldX;}
     void revertY(){y = oldY;}
     void setX(float nx){ oldX = x; x = dx = nx; }
     void setY(float ny){ oldY = y; y = dy = ny; }
     void setScreenXY(float nx, float ny){screenX = nx; screenY = ny;}
     int checkCollisions();
     virtual void collisionHappened(Sprite *other);
};

class AnimatedSprite : public Sprite
{
   private:
     int currentFrame;
     int startFrame;
     int endFrame;
     int animSpeed;
     bool animate;
   public:
     std::vector<BITMAP*> images;
     void draw();
     void drawFlip();
     void drawPivot();
     void update();
     void setAnimate(bool anim){ animate = anim; }
     void rewind() { currentFrame = 0; startFrame = 0; }
     int getFrame() {return currentFrame;}
     int getWidth(){return images[0]->w;}
     int getHeight(){return images[0]->h;}
     void addImage(BITMAP *img);
     AnimatedSprite(ENGINE *p, MapH *mp, bool dataBMP);
     AnimatedSprite(ENGINE *p, MapH *mp, float x, float y, bool dataBMP);
     ~AnimatedSprite();
};
/*
class HUD
{
   public:
     HUD(ENGINE *p, Hero *h);
     ~HUD();
     void update();
     void draw();
     ENGINE *parent;
     Hero *hro;
};
      */
class Hero  : public Sprite
{
      public:
        Hero(ENGINE *p, MapH *mp, float x, float y);
        ~Hero();
        void init();
        void update();
        void draw();
        int weaponOut;
        void collisionHappened(Sprite *other);
      private:
       // Collisions *col;
        Sprite *torso[2];
        Sprite *crosshair;
        AnimatedSprite *feet;
        //PMASK *maskFeet[7];
        Sprite *gun[2];
        Sprite *head[2];
        Sprite *feetJump[2];
        int bobage;
        //int swing;
        float shotAngle;
        bool canJump;
        bool isWalking, isFiring;
        int recoilTime;
       // HUD *hud;
};

class Bullet : public Sprite
{
   public:
     Bullet(ENGINE *p, MapH *mp, Sprite *gun, float angle, int dir);
     ~Bullet();
     void update();
     void draw();
     Sprite *bul;
     float myAngle;
     int timer;
};
/*
class Glass : public Sprite  //Glass?  That is like fragile things to break off of enemies
{
   public:
     Glass(ENGINE *p, MapH *mp, Sprite *junk);
     ~Glass();
     void update();
     void draw();
     Sprite *glassThing;
     int timer;
};*/

class Glass : public Sprite
{
   public:
     Glass(ENGINE *p, MapH *mp, Sprite *s, float xV, float yV);
     ~Glass();
     //void addSprite(Sprite *s);
     void update();
     void draw();
     int timer;
     float angle;
     float animAngle;
     float xVel, yVel;
     Sprite *thing;
     void collisionHappened(Sprite *other);
     //std::vector<Sprite*> things;
};

class HSR : public Sprite
{
   public:
     HSR(ENGINE *p, MapH *mp, float xp, float yp, int dir);
     ~HSR();
     void update();
     void draw();
     void collisionHappened(Sprite *other);
     bool movin;
     bool setOnce;
     bool headOn;
     bool torsoOn;
     int timer; //death sequence
   // int jumpAcceleration;
    // Glass *things[3];
     Sprite *tempSpr[5];
     BITMAP *temp[5];
     Glass *g[5];
     Sprite *head;
     Sprite *eyes;
     Sprite *legs[5];
     Sprite *torso;
     Sprite *mouth;
};


#endif
