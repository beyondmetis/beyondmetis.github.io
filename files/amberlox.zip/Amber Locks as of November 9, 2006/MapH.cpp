#include "MapH.h"

MapH::MapH(ENGINE* p)
{
    parent = p;
}

MapH::~MapH()
{
    MapFreeMem ();
    delete(camera);
    /*
    while(Entities.size()>0)
    {
      delete(Entities.back());
      Entities.pop_back();
    }*/
}

int MapH::init()
{
     if (MapLoad ("test.fmp")) {			/* Load the FMP file, exit if error */
	//	allegro_message ("Can't find %s, please run exe from same folder", (char*)named.c_str());
		allegro_message("Can't load map!");
        exit (0);
     }
     camera = new CAMERA(parent, this, NULL);   
     //number ents
     //what, and then x and y in pix
  /*
     PACKFILE *pfile;

	 pfile=pack_fopen("test.ent", "wp");

     pack_iputl(1,pfile);
     pack_iputl(0,pfile);
     pack_iputl(9*32, pfile);
     pack_iputl(30*32, pfile);

     pack_fclose(pfile);*/
 
     PACKFILE *pfile;

	pfile=pack_fopen("test.ent", "rp");

     int numberents =pack_igetl(pfile);

     for(int i = 0; i<numberents; i++)
     {
        int thing = pack_igetl(pfile);
        switch(thing)
        {
          case 0:
            Hero *h = new Hero(parent, this, pack_igetl(pfile), pack_igetl(pfile));
            camera->setFocus(h);
            addObj(h);
          break;
        }
     }
     pack_fclose(pfile);

     MapInitAnims ();    
     return 0;
           
}

void MapH::draw()
{
     //draw first 3 layers
     MapDrawBGT (parent->gHandler->getBuffer(), (int)camera->getX()/3, (int)camera->getY(), 0, 0, SCREEN_W, SCREEN_H);
     MapDrawFG (parent->gHandler->getBuffer(), (int)camera->getX(), (int)camera->getY(), 0, 0, SCREEN_W, SCREEN_H, 0);
     //draw the Entities and particle effects
     for(int i = Entities.size()-1; i>=0; i--)
     {
       Entities[i]->draw();
     }
    // MapChangeLayer(2);
     MapDrawFG (parent->gHandler->getBuffer(), (int)camera->getX(), (int)camera->getY(), 0, 0, SCREEN_W, SCREEN_H, 1);
  // for(int i = 0; i<collTiles.size(); i++)
    //   draw_allegro_pmask(collTiles[i]->mask, parent->gHandler->getBuffer(), collTiles[i]->x*32, collTiles[i]->y*32, 15);
     textprintf_ex(parent->gHandler->getBuffer(), font, 10, 10, makecol(255, 255, 255), -1, "ENTITIES: %d", Entities.size()); 
     textprintf_ex(parent->gHandler->getBuffer(), font, 10, 50, makecol(255, 255, 255), -1, "YPos: %f", ((Hero*)Entities[0])->getX());
}

void MapH::update()
{
     //update entities and particle effects
     for(int i = 0; i<Entities.size(); i++)
     {
         Entities[i]->checkCollisions();
         Entities[i]->update();
     }
      
     for(int i = 1; i<Entities.size(); i++)
     {
       if(!Entities[i]->checkActive())
         remObj(Entities[i]);
     }
     MapUpdateAnims ();
     camera->update();   
}

bool MapH::checkCollision(int x, int y)
{
     if(key[KEY_U])  //no clipping!
       return false;
     if(x%32<16)
     {
       if(y%32<16)
         return (MapGetBlock(x/32, y/32)->tl > 0);
       else return (MapGetBlock(x/32, y/32)->bl > 0);
     }
     else
     {
       if(y%32<16)
         return (MapGetBlock(x/32, y/32)->tr > 0);
       else return (MapGetBlock(x/32, y/32)->tl > 0);
     }
}
    
/*
    int x = (int)camera->getX();
    int y = (int)camera->getY();
    int d = (int)camera->getDirection();
	int margin = 120;
	if ((x < camera_x - margin + 640))
	{
        if(d==0)
		camera_x -= 10;
		if(x>camera_x-margin+640)
		 camera_x = x+margin-640;
		if (camera_x < 0) camera_x = 0;
	}
	if (y < camera_y + margin)
	{
        camera_y -= 8;
        if (camera_y < 0) camera_y = 0;
    }
	if ((x > (camera_x + margin)-40))
	{	
        if(d==1)				
		camera_x += 10;
		if(x<(camera_x+margin)-40)
		  camera_x = x-margin+40;
		if (camera_x > teg_pixelw(level) - 640)
			camera_x = teg_pixelw(level) - 640;
	}
	if (y > (camera_y + 480 - margin))
	{
        camera_y +=2;
        if (camera_y > teg_pixelh(level) - 480)
            camera_y = teg_pixelw(level) - 480;
    }*/


void MapH::remObj(Entity *o)
{
     std::vector<Entity*>::iterator i;
     for(i = Entities.begin(); i != Entities.end(); i++)
     {
        if((*i)==o)
        {
          Entities.erase(i);
          delete(o);
          return;
        }
          
     }
}

void MapH::addObj(Entity *o)
{
   //  while(Entities.back()!=o)
   //  {
        Entities.push_back(o);
   //  }
}
