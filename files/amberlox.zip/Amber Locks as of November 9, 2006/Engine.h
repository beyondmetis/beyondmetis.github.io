#ifndef engine_h
#define engine_h
//standards
#include <allegro.h>
#include <string>     
#include <map>
#include <vector>
//added libraries
#include <mappyal.h>  
#include <fblend.h>
#include <fmod.h>
#include "loadpng.h"
#include "pmask.h"
//my stuff
#include "rcs.h"     // .dat file
#include "GRAPHICSHANDLER.h"  // supposed to handle graphic stuff
#include "INPUTHANDLER.h"     // translates human phrases into keys
#include "SOUNDHANDLER.h"     // plays .spc and .wav files
#include "LOADHANDLER.h"      // loads the .dat file
#include "SCRIPTHANDLER.h"    //loads and runs the scripting
#include "MapH.h"              // handles the map engine
//class engines (reference, postdeclaration)
class GRAPHICSHANDLER;       
class INPUTHANDLER;
class LOADHANDLER;
class SOUNDHANDLER;
class MapH;
class SCRIPTHANDLER;

//ties all things together
class ENGINE 
{
   private:
     bool windowed;
     int update_counter;
     int update_speed;
     int frame_counter, fps;
   public:
     static volatile long game_counter, TICKS;
     static bool isQuit;
     int init();
     void run();
     void cleanup();
     GRAPHICSHANDLER *gHandler;
     LOADHANDLER *loadH;
     MapH *mHandler;
     SOUNDHANDLER *soundH;
     INPUTHANDLER *inputH;
     SCRIPTHANDLER *scriptH;
};

#endif
