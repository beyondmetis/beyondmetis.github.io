#include "Particle.h"

/*
Particle::Particle(int xP, int yP, float xV, float yV, int color, int life, ENGINE *p, MapH *m, bool grav)
{
   xPos = xP;
   yPos = yP;
   xVel = xV;
   yVel = yV;
   parent = p;
   mp = m;
   lifeSpan = life;
   scX = (int)(xPos - mp->getCameraX());
   scY = (int)(yPos - mp->getCameraY());
   this->color = color;
   useGravity = grav;
}

Particle::~Particle()
{
}

void Particle::draw()
{
    // for(int i = 0; i<200; i++)
     //  putpixel(parent->gHandler->getBuffer(), scX, scY, color);
   rectfill(parent->gHandler->getBuffer(), scX, scY, scX+1, scY+1, color);
}

void Particle::update()
{
     xPos+=xVel;
     yPos+=yVel;
     if(useGravity)
     {
       yVel+=.5;
      /* if(xPos>0&&yPos>0)
       if(mp->getFlag((int)xPos/32, (int)yPos/32)==1)
         yVel-=2.5;
       else
         yVel+=.5;
     }
     lifeSpan--;
     
     scX = (int)(xPos - mp->getCameraX());
     scY = (int)(yPos - mp->getCameraY());
     
     if(lifeSpan<=0)
      mp->remPtcl(this);
}*/
