#ifndef graphhandler
#define graphhandler
#include "Engine.h"

class ENGINE;

class GRAPHICSHANDLER
{
      public:
        GRAPHICSHANDLER(ENGINE *p);
        ~GRAPHICSHANDLER();
        int init();
        void flip();
        void takeScreenShot();
        BITMAP* getBuffer();
        //getObjects();
      private:
        int fullscreen;
        BITMAP *buffer;
        ENGINE *parent;
        int scrTakes;
        
};
#endif
