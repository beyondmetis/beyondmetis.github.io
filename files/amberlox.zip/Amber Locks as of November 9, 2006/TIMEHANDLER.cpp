#include "TIMEHANDLER.h"



TIMEHANDLER::TIMEHANDLER()
{
    totalTicks = 0;
    refreshTicks = 0;
}

void TIMEHANDLER::incrementRefreshCount()
{
    refreshTicks++;
    totalTicks++;
}

void TIMEHANDLER::init(volatile long* time)  //this is where the time starts
{    
    globalTime = time;
    oldGlobalTime = *time;
    totalTicks = 0;
    refreshTicks = 0;
}

void TIMEHANDLER::decrementRefreshCount()
{
     refreshTicks--;
}

long int TIMEHANDLER::getTime()
{
     return totalTicks;
}

void TIMEHANDLER::update()
{
     if(oldGlobalTime<(*globalTime))
     {
         totalTicks+=*globalTime-oldGlobalTime;
         refreshTicks+=*globalTime-oldGlobalTime;
         oldGlobalTime = *globalTime;
     }
}

int TIMEHANDLER::refreshCount()
{
    return refreshTicks;
}

TIMEHANDLER::~TIMEHANDLER()
{
}

