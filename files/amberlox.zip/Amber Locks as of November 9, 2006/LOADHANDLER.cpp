#include "LOADHANDLER.h"
#define DAT_PNG  DAT_ID('P','N','G',' ')

LOADHANDLER::LOADHANDLER(ENGINE *p)
{
   parent = p;
}

int LOADHANDLER::init()
{
    rcs = load_datafile("data.dat");
    if(!rcs)
    {
      allegro_message("Can't find data.dat");
      return 1;
    }  
    return 0;
}

void* LOADHANDLER::get(int k)
{
    if(rcs[k].dat == NULL)
    {
      allegro_message("data pointing to NULL space");
      return NULL;
    }

    return rcs[k].dat;
}

BITMAP *LOADHANDLER::grabFrame(int bmp, 
                               int width, int height, 
                               int startx, int starty, 
                               int columns, int frame)
{
    BITMAP *temp = create_bitmap(width,height);

    int x = startx + (frame % columns) * width;
    int y = starty + (frame / columns) * height;

    blit((BITMAP*)rcs[bmp].dat,temp,x,y,0,0,width,height);

    return temp;
}


BITMAP *LOADHANDLER::grabFrame(BITMAP *bmp, 
                               int width, int height, 
                               int startx, int starty, 
                               int columns, int frame)
{
    BITMAP *temp = create_bitmap(width,height);

    int x = startx + (frame % columns) * width;
    int y = starty + (frame / columns) * height;

    blit(bmp,temp,x,y,0,0,width,height);

    return temp;
}

BITMAP *LOADHANDLER::grabBitmap(int bmp)
{
    if(rcs[bmp].type != DAT_BITMAP && rcs[bmp].type != DAT_PNG)
      allegro_message("(BITMAP*)rcs[%d].dat is not a bitamp!", bmp);
    return (BITMAP*)rcs[bmp].dat;
}

LOADHANDLER::~LOADHANDLER()
{
    unload_datafile(rcs);
}
/*
ALSPC_DATA* LOADHANDLER::getSPC (const char *id)
{
	vector<DATAFILE*>::iterator i;
	DATAFILE *temp = NULL;
	for (i = data.begin(); i != data.end() && temp == NULL; ++i)
	{
			assert (*i);
			temp = find_datafile_object (*i, id.c_str());				
			// check if object is of the right type
			if (temp && temp->type != DAT_ALSPC)
					temp = NULL;
	}
	if (temp)
			return (ALSPC_DATA*)temp->dat;
	else
			return NULL;
}*/
