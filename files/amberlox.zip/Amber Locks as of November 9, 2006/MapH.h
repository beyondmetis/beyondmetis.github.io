#ifndef maphandler
#define maphandler

#include "Engine.h"
#include "Objects.h"
#include "Particle.h"

class ENGINE;
class Entity;
class CAMERA;
class AnimatedSprite;
class Hero;
class Bullet;
class Particle;

typedef struct SMASK {
   PMASK *mask;
   int x;
   int y;
} SMASK;

class MapH
{
      public:
        ENGINE *parent;
	    CAMERA *camera;
        MapH(ENGINE *p);
        ~MapH();
        int init();
        void draw();
        void update();
       /// void setCamerX(int nx) { camera->setFocus(NULL); camera->x_pos = nx; }
      ///  void setCamerY(int ny) { camera->setFocus(NULL); camera->y_pos = ny; }
        bool checkCollision(int x, int y);
        void addObj(Entity *o);
        void remObj(Entity *o);
        std::vector<Entity*> Entities;
};

#endif
      
