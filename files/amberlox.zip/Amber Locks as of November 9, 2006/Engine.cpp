#include "Engine.h"
#include <winalleg.h>

//static globals
volatile long ENGINE::game_counter = 0;
volatile long ENGINE::TICKS = 0;
bool ENGINE::isQuit = false;

void increment_counter() //A function to increment the game sequence
{
	ENGINE::game_counter++; // This will just increment the game counter by one. :)
    ENGINE::TICKS++;
}
END_OF_FUNCTION(increment_counter); 

void close_button (void)
{
	ENGINE::isQuit = true;
}
END_OF_FUNCTION(close_button);


int ENGINE::init() {
    LOCK_VARIABLE(ENGINE::game_counter);
    LOCK_FUNCTION(increment_counter);
    if (allegro_init () < 0)
	{
		allegro_message ("Allegro Init failed");
		return -1;
	}
	if (loadpng_init() < 0)
	{
        allegro_message ("LoadPng initialization failed");
        return -1;
    }
    
    if (install_timer() < 0)
	{
		allegro_message ("install timer failed");
		return -1;
	}
    
    install_pmask();
    
    set_window_title ("Amber LoX v0.15");
    set_close_button_callback (close_button);
    set_config_file("settings.ini");
    
    if (install_int_ex(increment_counter, BPS_TO_TIMER(40)) < 0)
	{
		allegro_message ("Timer Handler failed to install");
		return -1;
	}
	update_speed = 20;
	update_counter = 0;
	isQuit = false;
	
	gHandler = new GRAPHICSHANDLER(this);
	loadH = new LOADHANDLER(this);
	inputH = new INPUTHANDLER(this);
	mHandler = new MapH(this);
//	soundH = new SOUNDHANDLER(this);
    //scriptH = new SCRIPTHANDLER(this);
    
	if(gHandler->init())
    {
       allegro_message("Couldn't init Graphics!");
       return -1;
    }
    if(loadH->init())
    {
       allegro_message("Couldn't init Load Handle!");
       return -1;
    }
    if(inputH->init())
    {
       allegro_message("Couldn't init Input Handler!");
       return -1;
    }
    if(mHandler->init())
    {
       allegro_message("Couldn't init Map Handler!");
       return -1;
    }
  /*  if(soundH->init())
    {
       allegro_message("Couldn't init Sound Handler!");
       return -1;
    }*/
    /*if(scriptH->init())
    {
       allegro_message("Couldn't init Python Script");
       return -1;
    }*/
}

void ENGINE::run()
{  
    isQuit = false;
    update_counter = 0;
    fps = 0;
    frame_counter = 0;
    while(!isQuit)
    {
        //find frames per second with 20 beats per second
        if(update_counter>20)
        {
          fps = frame_counter;
          frame_counter = 0;
          update_counter = 0;
        }
        //update loop
        while (game_counter>0) 
        {
              //soundH->update();
              if(inputH->isTapped("escape"))
                 isQuit = true;
              mHandler->update();
              update_counter++;
              game_counter--;
        }
        mHandler->draw();
        textprintf_ex(gHandler->getBuffer(), font, 550, 450, makecol(255, 255, 0), -1, "FPS: %d", fps);
        if(inputH->isTapped("screenshot"))
          gHandler->takeScreenShot();
        gHandler->flip();
        frame_counter++;
        Sleep(1);
     }
}

void ENGINE::cleanup() {
     delete(gHandler);
     delete(loadH);
     delete(inputH);
   //  delete(soundH);
     delete(mHandler);
    // delete(scriptH);
}
