#include "GRAPHICSHANDLER.h"
  
GRAPHICSHANDLER::GRAPHICSHANDLER(ENGINE *p)
{
   parent = p;
   scrTakes = 0;
}

void GRAPHICSHANDLER::takeScreenShot()
{
      //BITMAP *bmp = create_sub_bitmap(screen, 0, 0, SCREEN_W, SCREEN_H);
      save_bitmap("Amber Lox.png", buffer, NULL);
}


void GRAPHICSHANDLER::flip()
{
     blit(buffer, screen, 0, 0, 0, 0, 640, 480);
     clear_bitmap(buffer);
}

int GRAPHICSHANDLER::init()
{
    fullscreen=get_config_int("graphics","fullscreen", 0);
    set_color_depth(32);
    if(fullscreen)
    {
       if(set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 640, 480, 0, 0))
       {
          allegro_message ("Couldn't set a windowed/fullscreen mode");
          return 1;
       }
    }
      
    else
    {
       if(set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0))
       {
         allegro_message ("Couldn't set a windowed/fullscreen mode");
          return 1;
       }
    }
    buffer = create_bitmap(640, 480);
    if(!buffer)
    {
        allegro_message ("Couldn't allocate a buffer image!");
        return 1;
    }    
    set_color_conversion(COLORCONV_KEEP_ALPHA);
    return 0;
}

BITMAP* GRAPHICSHANDLER::getBuffer()
{
   return buffer;
}

GRAPHICSHANDLER::~GRAPHICSHANDLER()
{
    parent = 0;
    destroy_bitmap(buffer);
}
