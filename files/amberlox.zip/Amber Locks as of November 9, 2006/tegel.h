//     :     :     :     :     :     :     :     :     :     :
//   --------:  ---------:  ---------:  ---------:  ----     :
// ..|      |*..|       |*..|       |*..|       |*..|  |*....:.
//   |      |*  |       |*  |       |*  |       |*  |  |*    :
//   ---  ---*  |  |-----*  |  |-----*  |  |-----*  |  |*    :
// ....|  |*.:..|  |--****..|  |-----*..|  |--****..|  |*....:.
//     |  |* :  |    |*  :  |  |--  |*  |    |*  :  |  |*    :
//     |  |* :  |  |--*  :  |  |*|  |*  |  |--*  :  |  |*    :
// ....|  |*.:..|  |-----:..|  ---  |*..|  |-----:..|  -----.:.
//     |  |* :  |       |*  |       |*  |       |*  |      |*:
//     |  |* :  |       |*  |       |*  |       |*  |      |*:
// ....----*.:..---------*..---------*..---------*..--------*:.
//     :**** :   *********   *********   *********   ********:
//     :     :     :     :     :     :     :     :     :     :
//
// Version 0.8
// Copyright (c) 2002-2004
// Martijn "Amarillion" van Iersel.
//
// This file is part of the Tegel tilemapping add-on for allegro
//
//    Tegel is free software; you can redistribute it and/or modify
//    it under the terms of the GNU Lesser General 
//    Public License as published by the Free Software 
//    Foundation; either version 2.1 of the License, or
//    (at your option) any later version.
//
//    Tegel is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public License
//    along with Tegel; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//	
// official website:
// http://tegel.sourceforge.net/
//
// I hope you like this program. Please send 
// questions, comments, flames and feature 
// requests to amarillion@yahoo.com.
//
#ifndef TEGEL_H
#define TEGEL_H

#include <allegro.h>

#ifdef __cplusplus
    extern "C" {
#endif

		
/**
	@name basic
	tegel.h
*/
//@{

/// flags for tilelist types
#define TEG_TILEFLAG_BMP 1
#define TEG_TILEFLAG_RLE 2
#define TEG_TILEFLAG_LARGE 3
#define TEG_TILEFLAG_LARGEI 0
        
/// dat id for tilelist datafile objects
#define DAT_TEG_TILELIST DAT_ID('T','E','G','T')
/// dat id for tilemap datafile objects
#define DAT_TEG_MAP DAT_ID('T','E','G','M')

/// contains a text description of the last error that occurred
extern char teg_error[256];


/** description of a single tile
    Depending on the type of the tilelist, this holds either a pointer to an RLE_SPRITE, 
	a BITMAP or it holds an index of a part of a larger BITMAP.
	the flags member may hold user defined information such as tile properties.
*/
typedef struct TEG_TILE
{	
    RLE_SPRITE* rle;	
    BITMAP *bmp;
    int index; 
	int flags;    
} TEG_TILE;

/**
    description of a set of tiles.
*/
typedef struct TEG_TILELIST
{
    int flags;
    // possible values: 
    // rle / bmp / large / largei
    // animated yes/no
    // attribs yes/no
    
    int tilew, tileh, tilenum;    
    // tilenum is number of indices
    
    int bpp;    
    int animsteps; // number of animation steps per cycle
    
    TEG_TILE* tiles; // list of tiles, tilenum * animsteps
    BITMAP* largebmp;
    RGB *pal;
    char *rawdata;
    int rawsize;
    
} TEG_TILELIST;

typedef struct TEG_MAP
{
    int *data; // array of int of size dl * w * h
    int dl, w, h; // number of layers, width and height
    TEG_TILELIST *tilelist;
} TEG_MAP;

/// create empty map
TEG_MAP *teg_createmap (int dl, int w, int h, TEG_TILELIST *tilelist);

/// load map from file. Tilelist may be null and set later
TEG_MAP *teg_loadmap (const char *filename, TEG_TILELIST *tilelist);

/// destroy a map
void teg_destroymap (TEG_MAP* map);

/// get index at a certain pos in the map
int teg_mapget (const TEG_MAP* map, int l, int x, int y);
/// put index at a certain pos in the map
void teg_mapput (TEG_MAP* map, int l, int x, int y, int val);

/// loads in tiles and links with bitmaps found in a datafile
TEG_TILELIST *teg_loadtiles (const char *filename, const DATAFILE *data);

/// destroy a tilelist.
void teg_destroytiles (TEG_TILELIST* tiles);

/// draws the tilemap scrolled by xview and yview.
void teg_draw (BITMAP *bmp, const TEG_MAP* map, int layer, int xview, int yview);

/// draws only a single frame
void teg_draw_frame (BITMAP *bmp, const TEG_MAP* map, int layer, int xview, int yview, int frame);

/// specialised funcs for rle, bmp, large or largei tilelists
void teg_draw_rle (BITMAP *bmp, const TEG_MAP* map, int layer, int xview, int yview, int frame);
void teg_draw_bmp (BITMAP *bmp, const TEG_MAP* map, int layer, int xview, int yview, int frame);
void teg_draw_large (BITMAP *bmp, const TEG_MAP* map, int layer, int xview, int yview, int frame);
void teg_draw_largei (BITMAP *bmp, const TEG_MAP* map, int layer, int xview, int yview, int frame);

/** idem as teg_draw, but only a part of the target bitmap will be drawn.
    x, y, w and h are relative to the target bitmap coordinates
    xview and yview are relative to the target bitmap (0,0), not to (x,y)
*/
void teg_partdraw (BITMAP *bmp, const TEG_MAP* map, int layer, int x, int y, int w, int h, int xview, int yview);
void teg_partdraw_rle (BITMAP *bmp, const TEG_MAP* map, int layer, int x, int y, int w, int h, int xview, int yview);
void teg_partdraw_bmp (BITMAP *bmp, const TEG_MAP* map, int layer, int x, int y, int w, int h, int xview, int yview);
void teg_partdraw_large (BITMAP *bmp, const TEG_MAP* map, int layer, int x, int y, int w, int h, int xview, int yview);
void teg_partdraw_largei (BITMAP *bmp, const TEG_MAP* map, int layer, int x, int y, int w, int h, int xview, int yview);

/// width of a map in pixels (equals width in tiles * width of a single tile)
int teg_pixelw(const TEG_MAP *map);
/// height of a map in pixels
int teg_pixelh(const TEG_MAP *map);

/// specialized datafile loading function
DATAFILE *teg_load_datafile (const char *datafile);
/// unload a datafile object
void teg_unload_datafile (DATAFILE *data);
/// initialization of tegel library, call this before any other tegel function
int teg_install();
/// cleanup of tegel library
void teg_uninstall();

////////////////////////////////////////
//extra functions
////////////////////////////////////////	    

// save a tilemap
void teg_savemap (TEG_MAP* map, char *filename);

/// copy a part of a map to another map
void teg_mapcopy (TEG_MAP *srcmap, TEG_MAP* destmap,
    int srcl, int srcx, int srcy,
    int destl, int destx, int desty,
    int dl, int w, int h);
        
/// copy constructor, create a new map that is a deep copy of the source object
TEG_MAP *teg_create_copy (TEG_MAP *src);

/// fill an area of a map with the same tile
void teg_maprect (TEG_MAP *destmap,
    int destl, int destx, int desty,
    int dl, int w, int h, int value);

/// resize a map, can be bigger or smaller. If the new size is smaller, the topleft portion is kept.
void teg_resizemap (TEG_MAP **map, int newdl, int neww, int newh);

/// draw a single tile, independant of the tile type
void teg_drawtile (BITMAP *dest, TEG_TILELIST *tiles, int index, int x, int y);

////////////////////////////////////////	    
//misc. GUI functions
////////////////////////////////////////

/// depracated
void resize_dialog (DIALOG *d);
/// depracated
void teg_showtext (char *title, char *filename);

////////////////////////////////////////
//other misc functions and definitions
////////////////////////////////////////

#define RED makecol (255, 0, 0)
#define BLUE makecol (0, 0, 255)
#define GREEN makecol (0, 255, 0)
#define YELLOW makecol (255, 255, 0)
#define BLACK makecol (0, 0, 0)
#define WHITE makecol (255, 255, 255)
#define GREY makecol (128, 128, 128)
#define CYAN makecol (0, 255, 255)
#define MAGENTA makecol (255, 0, 255)

#define TEG_MIN(x,y)     (((x) < (y)) ? (x) : (y))
#define TEG_MAX(x,y)     (((x) < (y)) ? (y) : (x))
#define TEG_BOUND(x,y,z)     (((y) < (x)) ? (((y) > (z)) ? (z) : (y)) : (x))

/// take a screenshot and save it as ss??????.pcx
void screenshot ();

/// change all rle objects in a datafile struct to bmp objects
void dat_rle2bmp (DATAFILE *data);
/// change one rle dat object into an bmp object
void dat_object_rle2bmp (DATAFILE *data);

/// funcs for temporarily changing a bitmap's clipping rect.
typedef int ClipRect[4];

void tempClipRect (BITMAP *bmp, ClipRect *cr, int x, int y, int w, int h);
void restoreClipRect (BITMAP *bmp, ClipRect *cr);

//@}

#ifdef __cplusplus
   }
#endif

#endif
