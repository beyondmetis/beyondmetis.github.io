/* Allegro datafile object indexes, produced by grabber v4.2.0, MinGW32 */
/* Datafile: c:\Dev-Cpp\allegro\tools\data.dat */
/* Date: Sun Sep 10 21:19:59 2006 */
/* Do not hand edit! */

#define ARMGUNLEFT                       0        /* BMP  */
#define ARMGUNRIGHT                      1        /* BMP  */
#define box                              2        /* BMP  */
#define BULLETLEFT                       3        /* BMP  */
#define BULLETRIGHT                      4        /* BMP  */
#define Crosshair                        5        /* PNG  */
#define FEET000                          6        /* BMP  */
#define FEET001                          7        /* BMP  */
#define FEET002                          8        /* BMP  */
#define FEET003                          9        /* BMP  */
#define FEET004                          10       /* BMP  */
#define FEET005                          11       /* BMP  */
#define FEET006                          12       /* BMP  */
#define FEETJUMP                         13       /* BMP  */
#define FONTA                            14       /* FONT */
#define HEADRIGHT                        15       /* BMP  */
#define HSREYES                          16       /* BMP  */
#define HSRHEAD                          17       /* BMP  */
#define HSRLEG                           18       /* BMP  */
#define HSRMOUTH                         19       /* BMP  */
#define HSRTORSO                         20       /* BMP  */
#define MENU                             21       /* BMP  */
#define MENUSCREEN                       22       /* BMP  */
#define SAMP0                            23       /* SAMP */
#define SAMP1                            24       /* SAMP */
#define SAMP2                            25       /* SAMP */
#define SELECT                           26       /* BMP  */
#define SFont                            27       /* FONT */
#define SPC0                             28       /* ASPC */
#define SPC1                             29       /* ASPC */
#define TORSOLEFT                        30       /* BMP  */
#define TORSORIGHT                       31       /* BMP  */

