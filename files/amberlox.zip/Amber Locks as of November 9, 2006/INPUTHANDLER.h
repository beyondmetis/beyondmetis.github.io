#ifndef inputhandler
#define inputhandler
#include <allegro.h>
#include "Engine.h"

class ENGINE;

class INPUTHANDLER
{
    public:
       typedef std::map<std::string, int> TABLE;
       TABLE keyMap;
       INPUTHANDLER(ENGINE *p);
       int init();
       void update(int k);
       void update(const char *c);
       bool isPressed(int k);
       bool isPressed(const char *c);
       bool isTapped(int k);   
       bool isTapped(const char *c);   
       ~INPUTHANDLER();
    private:
       int oldkeys[KEY_MAX];
       ENGINE *parent;
};

#endif
