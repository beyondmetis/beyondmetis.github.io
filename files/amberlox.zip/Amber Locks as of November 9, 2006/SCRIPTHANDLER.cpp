#include "SCRIPTHANDLER.h"
/*
SCRIPTHANDLER::SCRIPTHANDLER(ENGINE *p)
{
  parent = p;
  Py_Initialize();
}

SCRIPTHANDLER::~SCRIPTHANDLER()
{
  Py_Finalize();
}

void SCRIPTHANDLER::runFunction(std::string s)
{
}

int SCRIPTHANDLER::init()
{
    return 0;
}
*/
