#include "INPUTHANDLER.h"

INPUTHANDLER::INPUTHANDLER(ENGINE *p)
{
   parent = p;
}

int INPUTHANDLER::init()
{
     if(install_keyboard() < 0 || install_mouse() < 0)
     {
        allegro_message("Error installing inputs!");
        return 1;
     }
     keyMap["escape"] = KEY_ESC;
     keyMap["up"] = KEY_W;
     keyMap["down"] = KEY_S;
     keyMap["left"] = KEY_A;
     keyMap["right"] = KEY_D;
     keyMap["fire"] = KEY_Z;
     keyMap["weapon"] = KEY_TAB;
     keyMap["select"] = KEY_ENTER;
     keyMap["jump"] = KEY_SPACE;
     keyMap["screenshot"] = KEY_TILDE;
     
     return 0;
}

bool INPUTHANDLER::isPressed(int k)
{
     return (key[k]);
}

bool INPUTHANDLER::isPressed(const char *c)
{
     return key[keyMap[c]];
}

bool INPUTHANDLER::isTapped(int k)
{
     if (key[k])
     {
		if (oldkeys[k] == 0)
		{
			oldkeys[k] = 1;
			return 1;
		}
		return 0;
	 }
	 else
	 {
		oldkeys[k] = 0;
		return 0;
	 }
}

void INPUTHANDLER::update(int k)
{
     if(!key[k])
       oldkeys[k] = 0;
}

void INPUTHANDLER::update(const char *c)
{
     update(keyMap[c]);
}
     

bool INPUTHANDLER::isTapped(const char *c)
{
     return isTapped(keyMap[c]);
}

INPUTHANDLER::~INPUTHANDLER()
{
   delete []oldkeys;
   keyMap.clear();
}
