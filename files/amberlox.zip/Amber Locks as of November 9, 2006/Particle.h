#ifndef ParticleHe
#define ParticleHe

#include "Engine.h"
class ENGINE;
class MapH;

class Particle
{
      public:
      Particle(int xP, int yP, float xV, float yV, int color, int life, ENGINE *p, MapH *m, bool grav);
      ~Particle();
      void draw();
      void update();
      float xPos, yPos;
      int scX, scY;
      float xVel, yVel;
      int lifeSpan;
      int color;
      ENGINE *parent;
      MapH *mp;
      bool useGravity;
};

#endif
