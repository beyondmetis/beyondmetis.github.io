#ifndef timhandler
#define timhandler

extern volatile long TICKS;
extern volatile long game_counter;

#endif
