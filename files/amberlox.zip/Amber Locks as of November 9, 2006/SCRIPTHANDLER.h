#ifndef python_scripting
#define python_scripting
#include "Engine.h"
/*
class ENGINE;

class SCRIPTHANDLER
{
   public:
     SCRIPTHANDLER(ENGINE *p);
     ~SCRIPTHANDLER();
     int init();
     void runFunction(std::string s);
   private:
     ENGINE *parent;
};*/
#endif
