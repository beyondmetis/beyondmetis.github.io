//     :     :     :     :     :     :     :     :     :     :
//   --------:  ---------:  ---------:  ---------:  ----     :
// ..|      |*..|       |*..|       |*..|       |*..|  |*....:.
//   |      |*  |       |*  |       |*  |       |*  |  |*    :
//   ---  ---*  |  |-----*  |  |-----*  |  |-----*  |  |*    :
// ....|  |*.:..|  |--****..|  |-----*..|  |--****..|  |*....:.
//     |  |* :  |    |*  :  |  |--  |*  |    |*  :  |  |*    :
//     |  |* :  |  |--*  :  |  |*|  |*  |  |--*  :  |  |*    :
// ....|  |*.:..|  |-----:..|  ---  |*..|  |-----:..|  -----.:.
//     |  |* :  |       |*  |       |*  |       |*  |      |*:
//     |  |* :  |       |*  |       |*  |       |*  |      |*:
// ....----*.:..---------*..---------*..---------*..--------*:.
//     :**** :   *********   *********   *********   ********:
//     :     :     :     :     :     :     :     :     :     :
//
// Version 0.8
// Copyright (c) 2002-2004
// Martijn "Amarillion" van Iersel.
//
// This file is part of the Tegel tilemapping add-on for allegro
//
//    Tegel is free software; you can redistribute it and/or modify
//    it under the terms of the GNU Lesser General 
//    Public License as published by the Free Software 
//    Foundation; either version 2.1 of the License, or
//    (at your option) any later version.
//
//    Tegel is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public License
//    along with Tegel; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//	
// official website:
// http://tegel.sourceforge.net/
//
// I hope you like this program. Please send 
// questions, comments, flames and feature 
// requests to amarillion@yahoo.com.
//
#include <allegro.h>
#include "tegel.h"

#ifndef TEGMODE7_H
#define TEGMODE7_H

#ifdef __cplusplus
    extern "C" {
#endif

/* TEG_MODE_7_PARAMS is a struct that contains all different parameters
that are relevant for mode 7, so you can pass them to the functions
as a whole*/
typedef struct TEG_MODE_7_PARAMS
{
    fixed space_z; // this is the height of the camera above the plane.
    int horizon; // this is the number of pixels line 0 is below the horizon.
    fixed scale_x, scale_y; // this determines the scale of space coordinates
    // to screen coordinates
    fixed obj_scale_x, obj_scale_y; // this determines the relative size of
    // the ojects
} TEG_MODE_7_PARAMS;

void teg_draw_object (BITMAP *bmp, BITMAP *obj,
   fixed object_x, fixed object_y, fixed angle,
   fixed cx, fixed cy, TEG_MODE_7_PARAMS params);

/*
    blits bitmap tile repeating endlessly
*/
void teg_mode_7_sprite (BITMAP *bmp, BITMAP *tile, fixed angle, fixed cx, fixed cy, TEG_MODE_7_PARAMS params);

void teg_mode_7_map (BITMAP *bmp, TEG_MAP *map, fixed angle, fixed cx, fixed cy, TEG_MODE_7_PARAMS params);

#ifdef __cplusplus
    }
#endif

#endif
