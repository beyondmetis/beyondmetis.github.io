#ifndef soundhandler
#define soundhandler
#include "Engine.h"

class ENGINE;
/*
class SOUNDHANDLER
{
      public:
        SOUNDHANDLER(ENGINE *p);
        ~SOUNDHANDLER();
        int init();
        void update();
        void setVolume(int vol);
      private:
        ENGINE *parent;
        ALSPC_PLAYER *alspc_player;
        ALSPC_DATA *alspc_data;
        
};*/
#endif
