#ifndef loaddhandler
#define loaddhandler
#include "Engine.h"

class ENGINE;

class LOADHANDLER
{
    public:
       LOADHANDLER(ENGINE *p);
       int init();
       void* get(int k);
       BITMAP* grabFrame(int bmp, 
                               int width, int height, 
                               int startx, int starty, 
                               int columns, int frame);
       BITMAP* grabFrame(BITMAP *bmp, 
                               int width, int height, 
                               int startx, int starty, 
                               int columns, int frame);
       
       BITMAP* grabBitmap(int bmp);
       ~LOADHANDLER();
    private:
       DATAFILE *rcs;
       ENGINE *parent;
};

#endif
