#include "SOUNDHANDLER.h"
/*
SOUNDHANDLER::SOUNDHANDLER(ENGINE *p)
{
   alspc_install();
   parent = p;
   alspc_player = NULL;
   alspc_data = NULL;
}

SOUNDHANDLER::~SOUNDHANDLER()
{
   alspc_stop (alspc_player);        
   alspc_uninstall();
}

int SOUNDHANDLER::init()
{
     if (install_sound(DIGI_AUTODETECT, MIDI_NONE, NULL) < 0)
     {
        allegro_message("Could not install digital sound driver");
        return 1;
     }
     alspc_data = (ALSPC_DATA*)(parent->loadH->get(SPC1));
     alspc_player = alspc_start (alspc_data, 44100, 255, 128, 1, 1);
     
     return 0;
}

void SOUNDHANDLER::setVolume(int vol)
{
     voice_set_volume(alspc_player->stream->voice, vol);
     //alspc_player->stream->freq = vol;
}

void SOUNDHANDLER::update()
{
     alspc_poll (alspc_player);
}*/
